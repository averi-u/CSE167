﻿1. Averi (Zhizhen) Yu
2. zhy008 & zhy008@ucsd.edu
3.
5. Mac OS
