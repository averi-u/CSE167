﻿1. Averi (Zhizhen) Yu
2. zhy008@ucsd.edu
3. https://raviucsdgroup.s3.amazonaws.com/hw2/ddd469811ebeec63098ebcfbc8551031/20230206225722/index.html
4. It is in the top level folder.
5. Mac OS
6. Comments: I wish there are more clear information about the variables.
