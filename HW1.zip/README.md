﻿1. Averi (Zhizhen) Yu
2. zhy008@ucsd.edu
3. https://raviucsdgroup.s3.amazonaws.com/hw1/ddd469811ebeec63098ebcfbc8551031/20230127081655/index.html
4. It is in the top level folder.
5. Mac OS
6. Comments: The UCSD online section of fixing blackoutput, AKA modifying saveScreenshot function, would result in getting an extra duplicate screenshot of input.txt.000 as 001. I posted on piazza about this problem and fixed it by changing the code back to the original ones. 
